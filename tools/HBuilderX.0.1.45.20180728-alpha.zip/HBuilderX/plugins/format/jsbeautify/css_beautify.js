//console.log(fs);
var jsfile=process.argv[2];
var options=process.argv[3];
var beautify = require('js-beautify').css_beautify,
    fs = require('fs');

fs.readFile(jsfile, 'utf8', function (err, data) {
    if (err) {
        throw err;
    }
    console.log(beautify(data, eval('(' + options + ')')));
});