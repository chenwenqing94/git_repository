//console.log(fs);
var jsfile=process.argv[2];
var options=process.argv[3];
var outputfile = "E:/test.js";
var beautify = require('js-beautify').js_beautify,
    fs = require('fs');
fs.readFile(jsfile, 'utf8', function (err, data) {
    if (err) {
        throw err;
    }
    var output = beautify(data,eval('(' + options + ')'));
	console.log(output);
});
